XAMLUnityConnection is an example which shows how to connect between Unity and XAML.

To test the example, perform following steps:
* Open XAMLUnityConnection with UnityEditor
* Open 'test' scene
* Build XAML C# project from UnityEditor on top of XAMLUnityConnection\Export directory
* Open XAMLUnityConnection\Export\XAMLConnection.sln and build it.
* You should three sliders and a button drawn by Unity GUI. When you move the sliders you send data to Unity and the color of the cube changes. When you click on the button, you send data from Unity to XAML