An example showing how to use Settings menu together with Unity.

Quickstart:
* Open Unity project
* Open Example scene
* Build XAML C# solution (SDK 8.1) to Export folder
* Open the solution
* Build, Run
* Press Windows Key + C -> Settings -> Settings
* Change Music, Sound settings, see how Unity reacts to those changes
* Also note there's Privacy Policy button, this is a requirement, if you have InternetClient capability enabled. Read more: http://msdn.microsoft.com/en-us/library/windows/apps/hh770544.aspx

Note: App.xaml.cs was not changed and MainPage.xaml.cs has a single additional line (37), the additional code is in MainPageExtended.cs and SettingsPaneContent.xaml(.cs)