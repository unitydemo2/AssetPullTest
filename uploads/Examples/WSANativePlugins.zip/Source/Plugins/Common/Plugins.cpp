#include "stdafx.h"

extern "C" int __declspec(dllexport) _stdcall GetInteger()
{
	return 5;
}