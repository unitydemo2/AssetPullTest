XAMLUnityConnection is an example which shows how to connect between Unity and Metro.

Minimum 11-13 build is required.

To test the example, perform following steps:
* Open XAMLUnityConnection with UnityEditor
* Open test scene
* Build XAML C++ project from UnityEditor on top of XAMLConnection\Export directory
* Open XAMLConnection\Export\XAMLConnection.sln and hit F5
* You should three sliders and a button drawn by Unity GUI. When you move the sliders you send data to Unity and the color of the cube changes. When you click on the button, you send data from Unity to Metro.
* Also, check App.Xaml.cpp file, line 62:
	// Use MainPageEx which is written in C# and is located in MyCustomPlugin
	auto mainPage = ref new MyCustomPlugin::MainPageEx();

	// Use MainPage which is written in C++
	//auto mainPage = ref new MainPage();
Uncomment MainPage creation, so you can see how achieve the same in C++.