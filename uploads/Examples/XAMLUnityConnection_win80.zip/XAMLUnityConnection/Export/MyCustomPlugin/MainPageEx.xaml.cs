﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityPlayer;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using UnityEngine;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace MyCustomPlugin
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPageEx : Page
    {
        private int eventWasReceivedCount = 0;

        public MainPageEx()
        {
            this.InitializeComponent();

        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {

        }
        public void Initialize()
        {
            Communications.SetEvent(OnMetroEvent);
        }
        public SwapChainBackgroundPanel GetSwapChainBackgroundPanel()
        {
            return DXSwapChainPanel;
        }

        public void OnMetroEvent(object arg)
        {
            AppCallbacks.Instance.InvokeOnUIThread(new AppCallbackItem(() =>
                {
                    eventWasReceivedCount++;
                    textBox.Text = "Event received " + eventWasReceivedCount + " times";
                }
            ), false);


        }

        private void EventValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            byte r = (byte)redSlider.Value;
            byte g = (byte)greenSlider.Value;
            byte b = (byte)blueSlider.Value;
            if (AppCallbacks.Instance.IsInitialized())
            {
                AppCallbacks.Instance.InvokeOnAppThread(new AppCallbackItem(() =>
                    {
                        Communications.SetCubeMaterialColor(r, g, b);
                    }
                ), false);
            }

        }
    }
}
