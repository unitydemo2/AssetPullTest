using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace MyCustomPlugin
{
    public delegate void UnityEvent(object arg);

    public sealed class Communications
    {
        public static void SetCubeMaterialColor(byte r, byte g, byte b)
        {
            GameObject go = GameObject.Find("Cube");
            Material mat = go.GetComponent<XAMLConnection>().material;
            mat.color = new Color32(r, g, b, 255);
        }
        public static void SetEvent(UnityEvent e)
        {
            GameObject go = GameObject.Find("Cube");
            if (go != null)
            {
                go.GetComponent<XAMLConnection>().onEvent = new XAMLConnection.OnEvent(e);
            }
            else
            {
                throw new Exception("Cube not found, have exported the correct scene?");
            }
        }
    }
}
